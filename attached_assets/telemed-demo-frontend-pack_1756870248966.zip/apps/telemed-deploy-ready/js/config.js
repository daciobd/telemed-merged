// Ajuste aqui se os subdomínios mudarem
window.TELEMED_CFG = {
  AUCTION_URL: "https://telemed-auction.onrender.com",
  PRODUCTIVITY_URL: "https://telemed-productivity.onrender.com"
};
